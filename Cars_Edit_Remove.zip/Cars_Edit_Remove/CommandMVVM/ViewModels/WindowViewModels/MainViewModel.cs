﻿namespace CommandMVVM.ViewModels.WindowViewModels;

public  class MainViewModel
{
}
